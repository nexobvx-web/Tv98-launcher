package eu.webflowy.tv98;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#07070B");
    private static final int ACCENT = Color.parseColor("#00E5FF");
    private static final int MUTED = Color.parseColor("#A9A9B5");
    private static final int DEFAULT_TINT = Color.parseColor("#3D5AFE");
    private static final String[] TABS = {"Favorite", "Toate", "Jocuri", "Media", "Setări"};
    private static final int TAB_SETTINGS = 4;
    private static final int COLS = 5;
    private static final String KEY_FAVS = "favs";

    private static class AppItem {
        String label;
        String pkg;
        Intent launch;
        Drawable image;
        boolean banner;
        int category = -1;
        int tint = DEFAULT_TINT;
    }

    private final List<AppItem> apps = new ArrayList<>();
    private final TextView[] tabViews = new TextView[TABS.length];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private GridLayout grid;
    private TextView emptyView;
    private TextView heroTitle;
    private TextView heroHint;
    private TextView timeView;
    private TextView dateView;
    private View heroBox;
    private View underline;
    private FrameLayout tabsWrap;
    private GradientDrawable bg;
    private ValueAnimator tintAnim;
    private int curTint = DEFAULT_TINT;
    private int underlineBase;
    private int radius;
    private int tab = 1;
    private String lastPkg;
    private boolean firstShow = true;

    private static final String LOGO = "HACKED BY KAT";
    private final Random rnd = new Random();
    private TextView logoMain;
    private TextView logoRed;
    private TextView logoCyan;
    private int logoIdx = 0;

    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            logoIdx++;
            if (logoIdx >= LOGO.length()) {
                setLogoText(LOGO);
                handler.postDelayed(glitch, 1200);
            } else {
                setLogoText(LOGO.substring(0, logoIdx) + "_");
                handler.postDelayed(this, 75);
            }
        }
    };

    private final Runnable glitch = new Runnable() {
        private int frame = 0;

        @Override
        public void run() {
            if (frame < 6) {
                int d = dp(2) + rnd.nextInt(dp(4));
                int dir = rnd.nextBoolean() ? 1 : -1;
                logoRed.setAlpha(0.85f);
                logoCyan.setAlpha(0.85f);
                logoRed.setTranslationX(-d * dir);
                logoCyan.setTranslationX(d * dir);
                logoRed.setTranslationY(rnd.nextInt(3) - 1);
                logoCyan.setTranslationY(rnd.nextInt(3) - 1);
                setLogoText(frame % 2 == 0 ? scramble(LOGO) : LOGO);
                frame++;
                handler.postDelayed(this, 55);
            } else {
                logoRed.setAlpha(0f);
                logoCyan.setAlpha(0f);
                logoRed.setTranslationX(0f);
                logoCyan.setTranslationX(0f);
                logoRed.setTranslationY(0f);
                logoCyan.setTranslationY(0f);
                setLogoText(LOGO);
                frame = 0;
                handler.postDelayed(this, 2500 + rnd.nextInt(3500));
            }
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateClock();
            handler.postDelayed(this, 15000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("favorites", MODE_PRIVATE);
        radius = dp(14);
        underlineBase = dp(40);

        bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{darken(DEFAULT_TINT, 0.30f), BG});

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(bg);
        root.setPadding(dp(56), dp(24), dp(56), 0);

        // ---- Header: salut + nume aplicatie focusata | ceas ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout heroCol = new LinearLayout(this);
        heroCol.setOrientation(LinearLayout.VERTICAL);
        heroBox = heroCol;

        FrameLayout logoBox = new FrameLayout(this);
        logoRed = makeLogoText(Color.parseColor("#FF1744"));
        logoCyan = makeLogoText(ACCENT);
        logoMain = makeLogoText(Color.WHITE);
        logoRed.setAlpha(0f);
        logoCyan.setAlpha(0f);
        logoBox.addView(logoRed);
        logoBox.addView(logoCyan);
        logoBox.addView(logoMain);
        heroCol.addView(logoBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        heroTitle = new TextView(this);
        heroTitle.setTextColor(Color.WHITE);
        heroTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40);
        heroTitle.setTypeface(Typeface.DEFAULT_BOLD);
        heroTitle.setSingleLine(true);
        heroTitle.setEllipsize(TextUtils.TruncateAt.END);
        heroCol.addView(heroTitle);

        heroHint = new TextView(this);
        heroHint.setTextColor(MUTED);
        heroHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        heroHint.setSingleLine(true);
        heroCol.addView(heroHint);

        header.addView(heroCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout clockCol = new LinearLayout(this);
        clockCol.setOrientation(LinearLayout.VERTICAL);
        clockCol.setGravity(Gravity.END);
        timeView = new TextView(this);
        timeView.setTextColor(Color.WHITE);
        timeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 48);
        timeView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        timeView.setGravity(Gravity.END);
        clockCol.addView(timeView);
        dateView = new TextView(this);
        dateView.setTextColor(MUTED);
        dateView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        dateView.setGravity(Gravity.END);
        clockCol.addView(dateView);
        header.addView(clockCol, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header);

        // ---- Taburi cu bara animata ----
        tabsWrap = new FrameLayout(this);
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(TABS[i]);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            t.setPadding(dp(20), dp(8), dp(20), dp(16));
            t.setFocusable(true);
            t.setOnClickListener(v -> {
                if (idx == TAB_SETTINGS) {
                    openSettings();
                } else {
                    selectTab(idx);
                }
            });
            t.setOnFocusChangeListener((v, has) -> {
                if (has) {
                    setHero(greeting(), "Alege categoria cu săgețile");
                    animateTint(DEFAULT_TINT);
                }
                if (has && idx != TAB_SETTINGS && tab != idx) {
                    selectTab(idx);
                } else {
                    refreshTabs();
                }
            });
            tabViews[i] = t;
            tabsRow.addView(t, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        tabsWrap.addView(tabsRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        underline = new View(this);
        GradientDrawable ug = new GradientDrawable();
        ug.setColor(ACCENT);
        ug.setCornerRadius(dp(2));
        underline.setBackground(ug);
        underline.setPivotX(0f);
        FrameLayout.LayoutParams ulp = new FrameLayout.LayoutParams(underlineBase, dp(4),
                Gravity.BOTTOM | Gravity.START);
        tabsWrap.addView(underline, ulp);

        LinearLayout.LayoutParams twp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        twp.topMargin = dp(10);
        root.addView(tabsWrap, twp);

        emptyView = new TextView(this);
        emptyView.setTextColor(MUTED);
        emptyView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        emptyView.setPadding(dp(20), dp(24), dp(20), dp(24));
        emptyView.setVisibility(View.GONE);
        root.addView(emptyView);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        grid = new GridLayout(this);
        grid.setColumnCount(COLS);
        grid.setClipChildren(false);
        grid.setClipToPadding(false);
        grid.setPadding(dp(8), dp(12), dp(8), dp(90));
        scroll.addView(grid);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(scroll, slp);

        setContentView(root);
        refreshTabs();
        updateClock();
        setHero(greeting(), "Alege cu săgețile · OK deschide");
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        refreshTabs();
        buildGrid(lastPkg, firstShow);
        firstShow = false;
        tabsWrap.post(() -> moveUnderline(false));
        handler.post(tick);
        startLogo();
        if (getCurrentFocus() == null && grid.getChildCount() > 0) {
            grid.getChildAt(0).requestFocus();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
        handler.removeCallbacks(typer);
        handler.removeCallbacks(glitch);
        if (tintAnim != null) {
            tintAnim.cancel();
        }
    }

    @Override
    public void onBackPressed() {
        // Ramane pe ecranul principal.
    }

    // ---------------- logo ----------------

    private TextView makeLogoText(int color) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        t.setSingleLine(true);
        t.setText(LOGO);
        t.setVisibility(View.VISIBLE);
        return t;
    }

    private void setLogoText(String s) {
        logoMain.setText(s);
        logoRed.setText(s);
        logoCyan.setText(s);
    }

    private String scramble(String s) {
        String pool = "#@$%&*01<>/?";
        StringBuilder sb = new StringBuilder(s);
        for (int k = 0; k < 3; k++) {
            int i = rnd.nextInt(sb.length());
            if (sb.charAt(i) != ' ') {
                sb.setCharAt(i, pool.charAt(rnd.nextInt(pool.length())));
            }
        }
        return sb.toString();
    }

    private void startLogo() {
        handler.removeCallbacks(typer);
        handler.removeCallbacks(glitch);
        logoIdx = 0;
        setLogoText("_");
        handler.postDelayed(typer, 300);
    }

    // ---------------- utilitare ----------------

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private static int darken(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] = Math.max(0f, Math.min(1f, hsv[2] * factor));
        return Color.HSVToColor(hsv);
    }

    private String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h >= 5 && h < 12) {
            return "Bună dimineața";
        } else if (h >= 12 && h < 18) {
            return "Bună ziua";
        } else if (h >= 18 && h < 23) {
            return "Bună seara";
        }
        return "Noapte bună";
    }

    private void updateClock() {
        Date now = new Date();
        timeView.setText(new SimpleDateFormat("HH:mm", Locale.ROOT).format(now));
        String d = new SimpleDateFormat("EEEE, d MMMM", new Locale("ro", "RO")).format(now);
        if (d.length() > 0) {
            d = Character.toUpperCase(d.charAt(0)) + d.substring(1);
        }
        dateView.setText(d);
    }

    private void setHero(String title, String hint) {
        heroTitle.setText(title);
        heroHint.setText(hint);
        heroBox.setAlpha(0f);
        heroBox.setTranslationY(dp(10));
        heroBox.animate().alpha(1f).translationY(0f).setDuration(200)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void animateTint(int to) {
        if (tintAnim != null) {
            tintAnim.cancel();
        }
        tintAnim = ValueAnimator.ofObject(new ArgbEvaluator(), curTint, to);
        tintAnim.setDuration(450);
        tintAnim.addUpdateListener(an -> {
            curTint = (Integer) an.getAnimatedValue();
            bg.setColors(new int[]{darken(curTint, 0.34f), BG});
        });
        tintAnim.start();
    }

    private int dominant(Drawable d) {
        try {
            int s = 16;
            Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bm);
            Rect old = new Rect(d.getBounds());
            d.setBounds(0, 0, s, s);
            d.draw(c);
            d.setBounds(old);
            int[] px = new int[s * s];
            bm.getPixels(px, 0, s, 0, 0, s, s);
            bm.recycle();
            long r = 0, g = 0, b = 0;
            int n = 0;
            for (int p : px) {
                if (Color.alpha(p) < 200) {
                    continue;
                }
                r += Color.red(p);
                g += Color.green(p);
                b += Color.blue(p);
                n++;
            }
            if (n == 0) {
                return DEFAULT_TINT;
            }
            float[] hsv = new float[3];
            Color.RGBToHSV((int) (r / n), (int) (g / n), (int) (b / n), hsv);
            if (hsv[1] < 0.15f) {
                return DEFAULT_TINT;
            }
            hsv[1] = Math.min(1f, hsv[1] * 1.15f);
            hsv[2] = Math.max(hsv[2], 0.6f);
            return Color.HSVToColor(hsv);
        } catch (Exception e) {
            return DEFAULT_TINT;
        }
    }

    // ---------------- aplicatii ----------------

    private void loadApps() {
        apps.clear();
        Set<String> seen = new HashSet<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent query = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            List<ResolveInfo> list = getPackageManager().queryIntentActivities(query, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) {
                    continue;
                }
                String label = String.valueOf(ri.loadLabel(getPackageManager()));
                if (label.equalsIgnoreCase("All Apps")) {
                    seen.remove(pkg);
                    continue;
                }
                AppItem a = new AppItem();
                a.pkg = pkg;
                a.label = label;
                Drawable d = ri.activityInfo.loadBanner(getPackageManager());
                a.banner = d != null;
                if (d == null) {
                    d = ri.loadIcon(getPackageManager());
                }
                a.image = d;
                a.tint = dominant(d);
                if (Build.VERSION.SDK_INT >= 26) {
                    a.category = ri.activityInfo.applicationInfo.category;
                }
                a.launch = new Intent(Intent.ACTION_MAIN)
                        .addCategory(cat)
                        .setClassName(pkg, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                apps.add(a);
            }
        }
        Collections.sort(apps, (x, y) -> x.label.compareToIgnoreCase(y.label));
    }

    private boolean isFav(String pkg) {
        return prefs.getStringSet(KEY_FAVS, new HashSet<String>()).contains(pkg);
    }

    private boolean toggleFav(String pkg) {
        Set<String> favs = new HashSet<>(prefs.getStringSet(KEY_FAVS, new HashSet<String>()));
        boolean now;
        if (favs.contains(pkg)) {
            favs.remove(pkg);
            now = false;
        } else {
            favs.add(pkg);
            now = true;
        }
        prefs.edit().putStringSet(KEY_FAVS, favs).apply();
        return now;
    }

    private List<AppItem> filtered() {
        List<AppItem> out = new ArrayList<>();
        for (AppItem a : apps) {
            boolean ok;
            switch (tab) {
                case 0:
                    ok = isFav(a.pkg);
                    break;
                case 2:
                    ok = a.category == ApplicationInfo.CATEGORY_GAME;
                    break;
                case 3:
                    ok = a.category == ApplicationInfo.CATEGORY_AUDIO
                            || a.category == ApplicationInfo.CATEGORY_VIDEO
                            || a.category == ApplicationInfo.CATEGORY_IMAGE;
                    break;
                default:
                    ok = true;
            }
            if (ok) {
                out.add(a);
            }
        }
        return out;
    }

    // ---------------- taburi ----------------

    private void selectTab(int i) {
        tab = i;
        refreshTabs();
        moveUnderline(true);
        buildGrid(null, true);
    }

    private void refreshTabs() {
        for (int i = 0; i < tabViews.length; i++) {
            TextView t = tabViews[i];
            if (t == null) {
                continue;
            }
            boolean selected = (i == tab);
            t.setTextColor(selected ? Color.WHITE : MUTED);
            t.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(20));
            g.setColor(t.isFocused() ? Color.parseColor("#26FFFFFF") : Color.TRANSPARENT);
            t.setBackground(g);
        }
    }

    private void moveUnderline(boolean animate) {
        TextView t = tabViews[tab];
        if (t == null || t.getWidth() == 0) {
            return;
        }
        float x = t.getLeft() + dp(20);
        float sx = (t.getWidth() - dp(40)) / (float) underlineBase;
        if (animate) {
            underline.animate().translationX(x).scaleX(sx).setDuration(240)
                    .setInterpolator(new DecelerateInterpolator()).start();
        } else {
            underline.setTranslationX(x);
            underline.setScaleX(sx);
        }
    }

    // ---------------- grila ----------------

    private void buildGrid(String focusPkg, boolean animate) {
        grid.removeAllViews();
        List<AppItem> list = filtered();

        if (list.isEmpty()) {
            emptyView.setText(tab == 0
                    ? "Nu ai favorite încă. Ține apăsat OK pe o aplicație din „Toate”."
                    : "Nicio aplicație în această categorie.");
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }

        int screenW = getResources().getDisplayMetrics().widthPixels;
        int margin = dp(8);
        int avail = screenW - dp(56) * 2 - dp(8) * 2;
        int tileW = avail / COLS - margin * 2;
        int imgH = tileW * 9 / 16;

        View toFocus = null;
        int index = 0;
        for (AppItem a : list) {
            FrameLayout cell = new FrameLayout(this);
            cell.setClipChildren(false);
            View tile = makeTile(a, imgH, cell);
            cell.addView(tile, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = tileW;
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            lp.setMargins(margin, margin, margin, margin);
            grid.addView(cell, lp);

            if (animate) {
                cell.setAlpha(0f);
                cell.setTranslationY(dp(28));
                cell.animate().alpha(1f).translationY(0f)
                        .setStartDelay(Math.min(index, 14) * 30L)
                        .setDuration(260)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
            }
            if (a.pkg.equals(focusPkg)) {
                toFocus = tile;
            }
            index++;
        }
        if (toFocus != null) {
            toFocus.requestFocus();
        }
    }

    private GradientDrawable panelBg(AppItem a) {
        GradientDrawable g;
        if (a.banner) {
            g = new GradientDrawable();
            g.setColor(Color.parseColor("#1A1A22"));
        } else {
            g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{darken(a.tint, 0.55f), darken(a.tint, 0.22f)});
        }
        g.setCornerRadius(radius);
        return g;
    }

    private View makeTile(final AppItem a, int imgH, final View cell) {
        final FrameLayout tile = new FrameLayout(this);
        tile.setFocusable(true);
        tile.setTag(a.pkg);
        tile.setBackground(panelBg(a));
        tile.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        tile.setClipToOutline(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.image);
        if (a.banner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(22), dp(22), dp(22), dp(22));
        }
        col.addView(iv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, imgH));

        TextView tv = new TextView(this);
        tv.setText((isFav(a.pkg) ? "★ " : "") + a.label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(dp(12), dp(9), dp(12), dp(10));
        col.addView(tv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tile.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final View border = new View(this);
        GradientDrawable bd = new GradientDrawable();
        bd.setColor(Color.TRANSPARENT);
        bd.setCornerRadius(radius);
        bd.setStroke(dp(3), Color.WHITE);
        border.setBackground(bd);
        border.setAlpha(0f);
        tile.addView(border, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        tile.setOnFocusChangeListener((v, has) -> {
            float s = has ? 1.1f : 1f;
            v.animate().scaleX(s).scaleY(s).setDuration(has ? 200 : 140)
                    .setInterpolator(has ? new OvershootInterpolator(1.6f) : new DecelerateInterpolator())
                    .start();
            border.animate().alpha(has ? 1f : 0f).setDuration(150).start();
            cell.setTranslationZ(has ? dp(10) : 0);
            if (has) {
                lastPkg = a.pkg;
                setHero(a.label, "OK · deschide      OK lung · favorite");
                animateTint(a.tint);
            }
        });
        tile.setOnClickListener(v -> {
            try {
                startActivity(a.launch);
            } catch (Exception e) {
                Toast.makeText(this, "Nu pot porni " + a.label, Toast.LENGTH_SHORT).show();
            }
        });
        tile.setOnLongClickListener(v -> {
            boolean now = toggleFav(a.pkg);
            Toast.makeText(this, now ? "Adăugat la favorite" : "Scos din favorite",
                    Toast.LENGTH_SHORT).show();
            buildGrid(a.pkg, false);
            return true;
        });
        return tile;
    }

    private void openSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Toast.makeText(this, "Nu pot deschide Setările", Toast.LENGTH_SHORT).show();
        }
    }
}
