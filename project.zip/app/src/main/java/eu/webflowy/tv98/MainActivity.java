package eu.webflowy.tv98;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#0B0B0F");
    private static final int PANEL = Color.parseColor("#1A1A22");
    private static final int ACCENT = Color.parseColor("#00E5FF");
    private static final int MUTED = Color.parseColor("#B0B0B8");
    private static final String[] TABS = {"Favorite", "Toate", "Jocuri", "Media", "Setări"};
    private static final int TAB_SETTINGS = 4;
    private static final int COLS = 5;
    private static final String KEY_FAVS = "favs";

    private static class AppItem {
        String label;
        String pkg;
        Intent launch;
        Drawable image;
        boolean banner;
        int category = -1;
    }

    private final List<AppItem> apps = new ArrayList<>();
    private final TextView[] tabViews = new TextView[TABS.length];
    private SharedPreferences prefs;
    private GridLayout grid;
    private TextView emptyView;
    private int tab = 1;
    private String lastPkg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("favorites", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(56), dp(28), dp(56), dp(20));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("TV98");
        title.setTextColor(ACCENT);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm  ·  EEE, d MMM");
        clock.setFormat12Hour("HH:mm  ·  EEE, d MMM");
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        header.addView(clock);
        root.addView(header);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(TABS[i]);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            t.setPadding(dp(20), dp(8), dp(20), dp(8));
            t.setFocusable(true);
            t.setOnClickListener(v -> {
                if (idx == TAB_SETTINGS) {
                    openSettings();
                } else {
                    selectTab(idx);
                }
            });
            t.setOnFocusChangeListener((v, has) -> {
                if (has && idx != TAB_SETTINGS && tab != idx) {
                    selectTab(idx);
                } else {
                    refreshTabs();
                }
            });
            tabViews[i] = t;
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.rightMargin = dp(8);
            tabs.addView(t, tlp);
        }
        LinearLayout.LayoutParams tabsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tabsLp.topMargin = dp(16);
        root.addView(tabs, tabsLp);

        emptyView = new TextView(this);
        emptyView.setTextColor(MUTED);
        emptyView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        emptyView.setPadding(dp(20), dp(24), dp(20), dp(24));
        emptyView.setVisibility(View.GONE);
        root.addView(emptyView);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        grid = new GridLayout(this);
        grid.setColumnCount(COLS);
        grid.setClipChildren(false);
        grid.setClipToPadding(false);
        grid.setPadding(dp(8), dp(12), dp(8), dp(24));
        scroll.addView(grid);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(8);
        root.addView(scroll, slp);

        setContentView(root);
        refreshTabs();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        refreshTabs();
        buildGrid(lastPkg);
        if (getCurrentFocus() == null && grid.getChildCount() > 0) {
            grid.getChildAt(0).requestFocus();
        }
    }

    @Override
    public void onBackPressed() {
        // Ramane pe ecranul principal.
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private void loadApps() {
        apps.clear();
        Set<String> seen = new HashSet<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent query = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            List<ResolveInfo> list = getPackageManager().queryIntentActivities(query, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) {
                    continue;
                }
                AppItem a = new AppItem();
                a.pkg = pkg;
                a.label = String.valueOf(ri.loadLabel(getPackageManager()));
                Drawable d = ri.activityInfo.loadBanner(getPackageManager());
                a.banner = d != null;
                if (d == null) {
                    d = ri.loadIcon(getPackageManager());
                }
                a.image = d;
                if (Build.VERSION.SDK_INT >= 26) {
                    a.category = ri.activityInfo.applicationInfo.category;
                }
                a.launch = new Intent(Intent.ACTION_MAIN)
                        .addCategory(cat)
                        .setClassName(pkg, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                apps.add(a);
            }
        }
        Collections.sort(apps, (x, y) -> x.label.compareToIgnoreCase(y.label));
    }

    private boolean isFav(String pkg) {
        return prefs.getStringSet(KEY_FAVS, new HashSet<String>()).contains(pkg);
    }

    private boolean toggleFav(String pkg) {
        Set<String> favs = new HashSet<>(prefs.getStringSet(KEY_FAVS, new HashSet<String>()));
        boolean now;
        if (favs.contains(pkg)) {
            favs.remove(pkg);
            now = false;
        } else {
            favs.add(pkg);
            now = true;
        }
        prefs.edit().putStringSet(KEY_FAVS, favs).apply();
        return now;
    }

    private List<AppItem> filtered() {
        List<AppItem> out = new ArrayList<>();
        for (AppItem a : apps) {
            boolean ok;
            switch (tab) {
                case 0:
                    ok = isFav(a.pkg);
                    break;
                case 2:
                    ok = a.category == ApplicationInfo.CATEGORY_GAME;
                    break;
                case 3:
                    ok = a.category == ApplicationInfo.CATEGORY_AUDIO
                            || a.category == ApplicationInfo.CATEGORY_VIDEO
                            || a.category == ApplicationInfo.CATEGORY_IMAGE;
                    break;
                default:
                    ok = true;
            }
            if (ok) {
                out.add(a);
            }
        }
        return out;
    }

    private void selectTab(int i) {
        tab = i;
        refreshTabs();
        buildGrid(null);
    }

    private void refreshTabs() {
        for (int i = 0; i < tabViews.length; i++) {
            TextView t = tabViews[i];
            if (t == null) {
                continue;
            }
            boolean selected = (i == tab);
            t.setTextColor(selected ? ACCENT : MUTED);
            t.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(20));
            g.setColor(t.isFocused() ? Color.parseColor("#33FFFFFF") : Color.TRANSPARENT);
            t.setBackground(g);
        }
    }

    private void buildGrid(String focusPkg) {
        grid.removeAllViews();
        List<AppItem> list = filtered();

        if (list.isEmpty()) {
            emptyView.setText(tab == 0
                    ? "Nu ai favorite încă. Ține apăsat OK pe o aplicație din „Toate”."
                    : "Nicio aplicație în această categorie.");
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }

        int screenW = getResources().getDisplayMetrics().widthPixels;
        int margin = dp(8);
        int avail = screenW - dp(56) * 2 - dp(8) * 2;
        int tileW = avail / COLS - margin * 2;
        int imgH = tileW * 9 / 16;

        View toFocus = null;
        for (AppItem a : list) {
            View tile = makeTile(a, imgH);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = tileW;
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            lp.setMargins(margin, margin, margin, margin);
            grid.addView(tile, lp);
            if (a.pkg.equals(focusPkg)) {
                toFocus = tile;
            }
        }
        if (toFocus != null) {
            toFocus.requestFocus();
        }
    }

    private GradientDrawable tileBg(boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(PANEL);
        g.setCornerRadius(dp(10));
        if (focused) {
            g.setStroke(dp(3), ACCENT);
        }
        return g;
    }

    private View makeTile(final AppItem a, int imgH) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setFocusable(true);
        tile.setTag(a.pkg);
        tile.setBackground(tileBg(false));
        tile.setPadding(dp(3), dp(3), dp(3), dp(3));

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.image);
        if (a.banner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(18), dp(18), dp(18), dp(18));
        }
        tile.addView(iv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, imgH));

        TextView tv = new TextView(this);
        tv.setText((isFav(a.pkg) ? "★ " : "") + a.label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(dp(10), dp(8), dp(10), dp(8));
        tile.addView(tv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tile.setOnFocusChangeListener((v, has) -> {
            v.setBackground(tileBg(has));
            float s = has ? 1.08f : 1f;
            v.animate().scaleX(s).scaleY(s).setDuration(120).start();
            v.setTranslationZ(has ? dp(8) : 0);
            if (has) {
                lastPkg = a.pkg;
            }
        });
        tile.setOnClickListener(v -> {
            try {
                startActivity(a.launch);
            } catch (Exception e) {
                Toast.makeText(this, "Nu pot porni " + a.label, Toast.LENGTH_SHORT).show();
            }
        });
        tile.setOnLongClickListener(v -> {
            boolean now = toggleFav(a.pkg);
            Toast.makeText(this, now ? "Adăugat la favorite" : "Scos din favorite",
                    Toast.LENGTH_SHORT).show();
            buildGrid(a.pkg);
            return true;
        });
        return tile;
    }

    private void openSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Toast.makeText(this, "Nu pot deschide Setările", Toast.LENGTH_SHORT).show();
        }
    }
}
